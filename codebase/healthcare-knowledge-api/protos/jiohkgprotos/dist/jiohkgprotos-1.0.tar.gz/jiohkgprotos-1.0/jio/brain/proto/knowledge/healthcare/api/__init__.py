from . import healthcare_kg_service_pb2
from . import healthcare_kg_service_pb2_grpc
