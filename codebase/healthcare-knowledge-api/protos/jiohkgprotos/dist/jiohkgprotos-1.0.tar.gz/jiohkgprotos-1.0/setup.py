
import setuptools

setuptools.setup(
    name="jiohkgprotos",
    version="1.0",
    author="me",
    author_email="me@example.com",
    description="Knowlegde graph apis",
    long_description="",
    long_description_content_type="text/markdown",
    packages=setuptools.find_packages("."),

)
