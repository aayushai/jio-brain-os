NAMESPACE_DELIMITER = "_"

# schema_attribute log messages
ADD_SCHEMA_ATTRIBUTE_START = "add_schema_attribute method entered"
ADD_SCHEMA_ATTRIBUTE_COMPLETED = "add_schema_attribute method entered"
GET_SCHEMA_ATTRIBUTE_START = "get_schema_attribute method entered"
GET_SCHEMA_ATTRIBUTE_COMPLETED = "get_schema_attribute method entered"
DELETE_SCHEMA_ATTRIBUTE_START = "delete_schema_attribute method entered"
DELETE_SCHEMA_ATTRIBUTE_COMPLETED = "delete_schema_attribute method entered"