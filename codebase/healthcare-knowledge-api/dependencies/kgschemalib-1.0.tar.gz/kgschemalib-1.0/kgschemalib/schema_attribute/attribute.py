import logging as logger
from .config import *
from .query import *
from kgschemalib.arango_utils.query_handler import process_query

def add_schema_attribute(self, collection_name, metadata):
    logger.debug(ADD_SCHEMA_ATTRIBUTE_START)

    query_list = []
    format = "{ _key: '%s', attribute_type: '%s', quantity_type: '%s' }"
    for attribute in metadata:
        key = collection_name + NAMESPACE_DELIMITER + attribute
        attribute_type = metadata[attribute][0]
        quantity_type = metadata[attribute][1]
        query_list.append(format % (key, attribute_type, quantity_type))

    query = add_query
    query_ = (query % query_list).replace('"', '')
    cursor,status = process_query(self,query_)

    logger.info(ADD_SCHEMA_ATTRIBUTE_COMPLETED)
    return status


def delete_schema_attribute(self, vertical, entity_type, attribute_name): #assuming exists
    logger.debug(DELETE_SCHEMA_ATTRIBUTE_START)

    query = delete_query
    key = vertical+NAMESPACE_DELIMITER+entity_type+NAMESPACE_DELIMITER+attribute_name
    query_ = query%(key)
    cursor,status = process_query(self, query_)

    logger.info(DELETE_SCHEMA_ATTRIBUTE_COMPLETED)
    return status

def delete_all_schema_attribute(self, vertical, entity_type, attribute_name): #assuming exists
    logger.debug(DELETE_SCHEMA_ATTRIBUTE_START)
    queries = []
    query = delete_query
    for i in range (len(attribute_name)):
        key = vertical+NAMESPACE_DELIMITER+entity_type+NAMESPACE_DELIMITER+attribute_name[i]
        queries.append(query%(key))
    for i in range(len(queries)):
        cursor,status = process_query(self, queries[i])
  
    logger.info(DELETE_SCHEMA_ATTRIBUTE_COMPLETED)
    return status


def get_schema_attribute(self, vertical, entity_type, attribute_name):
    logger.debug(GET_SCHEMA_ATTRIBUTE_START)

    query = get_query
    key = "schema_attribute/"+vertical+NAMESPACE_DELIMITER+entity_type+NAMESPACE_DELIMITER+attribute_name
    query_ = query%(key)
    cursor,status = process_query(self, query_)

    logger.info(GET_SCHEMA_ATTRIBUTE_COMPLETED)
    return cursor, status