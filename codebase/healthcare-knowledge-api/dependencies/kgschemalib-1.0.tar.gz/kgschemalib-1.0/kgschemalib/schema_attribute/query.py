add_query = "FOR doc in %s \
        INSERT doc IN schema_attribute"

delete_query = "REMOVE {_key: '%s'} in schema_attribute"

get_query = "LET doc = DOCUMENT('%s') \
        RETURN { attribute_type: doc.attribute_type, quantity_type: doc.quantity_type}"