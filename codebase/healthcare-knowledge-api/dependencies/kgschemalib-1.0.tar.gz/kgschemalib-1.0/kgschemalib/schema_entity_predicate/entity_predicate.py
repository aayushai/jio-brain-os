import logging as logger
from .config import *
from .query import *
from kgschemalib.arango_utils.query_handler import process_query

def add_schema_entity_predicate(self, collection_name, metadata):
    logger.debug(ADD_SCHEMA_ENTITY_PREDICATE_START)

    query = add_query
    query_ = query%(collection_name,collection_name,collection_name,collection_name,metadata["static_attributes"], metadata["dynamic_attributes"],collection_name,collection_name,metadata["static_attributes"],collection_name,metadata["dynamic_attributes"])

    print(query_)
    cursor,status = process_query(self,query_)

    logger.info(ADD_SCHEMA_ENTITY_PREDICATE_COMPLETED)
    return status

def delete_schema_entity_predicate(self, vertical, entity_type, attribute_type, attribute_name): #assuming exists
    logger.debug(DELETE_SCHEMA_ENTITY_PREDICATE_START)

    if attribute_type == "static":
        query = delete_query_static
    elif attribute_type == "dynamic":
        query = delete_query_dynamic
    
    collection_name = vertical+NAMESPACE_DELIMITER+entity_type
    query_ = query%(collection_name,collection_name,collection_name,attribute_name)
    cursor,status = process_query(self, query_)

    logger.info(DELETE_SCHEMA_ENTITY_PREDICATE_COMPLETED)
    return status

def delete_all_schema_entity_predicate(self, vertical, entity_type): #assuming exists
    logger.debug(DELETE_SCHEMA_ENTITY_PREDICATE_START)

    query = delete_all_query
    collection_name = vertical+NAMESPACE_DELIMITER+entity_type
    query_ = query%(collection_name)
    cursor,status = process_query(self, query_)

    logger.info(DELETE_SCHEMA_ENTITY_PREDICATE_COMPLETED)
    return status

def get_schema_entity_predicate(self, vertical, entity_type):
    logger.debug(GET_SCHEMA_ENTITY_PREDICATE_START)
    
    query = get_query
    collection_name = vertical+NAMESPACE_DELIMITER+entity_type
    query_ = query%(self, collection_name,collection_name,collection_name)
    cursor,status = process_query(query_)

    logger.info(GET_SCHEMA_ENTITY_PREDICATE_COMPLETED)
    return cursor, status