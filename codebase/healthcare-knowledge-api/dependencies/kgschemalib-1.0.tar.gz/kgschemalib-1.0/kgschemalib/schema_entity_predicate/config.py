NAMESPACE_DELIMITER = "_"

# schema_entity_predicate log messages
ADD_SCHEMA_ENTITY_PREDICATE_START = "add_schema_entity_predicate method entered"
ADD_SCHEMA_ENTITY_PREDICATE_COMPLETED = "add_schema_entity_predicate method entered"
GET_SCHEMA_ENTITY_PREDICATE_START = "get_schema_entity_predicate method entered"
GET_SCHEMA_ENTITY_PREDICATE_COMPLETED = "get_schema_entity_predicate method entered"
DELETE_SCHEMA_ENTITY_PREDICATE_START = "delete_schema_entity_predicate method entered"
DELETE_SCHEMA_ENTITY_PREDICATE_COMPLETED = "delete_schema_entity_predicate method entered"