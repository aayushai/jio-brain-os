add_query = "LET doc = document('schema_entity_predicate/%s') \
        UPSERT { _key: '%s' } \
        INSERT { _key: '%s', '%s': {  'static': %s,  'dynamic': %s  } }  \
        UPDATE {%s:{static:append(doc.%s.static, %s, true), dynamic:append(doc.%s.dynamic,%s, true)}} \
        IN schema_entity_predicate"

delete_query_static = "LET doc = DOCUMENT('schema_entity_predicate/%s') \
            UPDATE doc WITH {%s: {static: remove_value(doc.%s.static, '%s')}} IN schema_entity_predicate"

delete_query_dynamic = "LET doc = DOCUMENT('schema_entity_predicate/%s') \
            UPDATE doc WITH {%s: {dynamic: remove_value(doc.%s.dynamic, '%s')}} IN schema_entity_predicate"

get_query = "LET doc = DOCUMENT('schema_entity_predicate/%s') \
        RETURN { static_attributes: doc.%s.static, dynamic_attributes: doc.%s.dynamic}"

delete_all_query = "REMOVE {_key: '%s'} in schema_entity_predicate"
# LET doc = document('schema_entity_predicate/common_person')
# UPSERT { _key: 'common_person' }
# INSERT { _key: 'common_person', 'common_person': {  'static': ['age'],  'dynamic': "" } }
# UPDATE { common_person:{static:append(doc.common_person.static,['age1']), dynamic:append(doc.common_person.dynamic,[])}}
# IN schema_entity_predicate
# return doc