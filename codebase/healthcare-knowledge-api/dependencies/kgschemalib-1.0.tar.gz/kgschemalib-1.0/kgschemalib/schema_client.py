from retry import retry
import logging as logger
from arango import ArangoClient
from singleton_decorator import singleton
from .schema_vertical.vertical import *
from .schema_attribute.attribute import *
from .schema_entity_predicate.entity_predicate import *

@singleton
class SchemaClient:
    def __init__(self,host,db_name,username,password):
        self.db = self.initiate_connection(host,db_name,username,password)

    @retry((Exception), tries=3, logger=logger)
    def initiate_connection(self,host,db_name,username,password):
        client = ArangoClient(hosts=host)
        db = client.db(db_name, username=username, password=password)
        return db

    def add_collection_type(self,vertical,attribute,entity_predicate):
        add_schema_vertical(self,vertical["is_predicate"],vertical["vertical"],vertical["entity_type"])
        add_schema_attribute(self,attribute["collection_name"],attribute["schema_attribute"])
        add_schema_entity_predicate(self,entity_predicate["collection_name"],entity_predicate["schema_entity_predicate"])


    def add_attribute_type(self,attribute, entity_predicate):
        add_schema_attribute(self,attribute["collection_name"],attribute["schema_attribute"])
        add_schema_entity_predicate(self,entity_predicate["collection_name"],entity_predicate["schema_entity_predicate"])

    def delete_collection_type(self,vertical,attribute,entity_predicate):
        delete_schema_vertical(self,vertical["is_predicate"],vertical["vertical"],vertical["entity_type"])
        delete_all_schema_attribute(self,attribute["vertical"],attribute["entity_type"],attribute["attribute_name"])
        delete_all_schema_entity_predicate(self,entity_predicate["vertical"],entity_predicate["entity_type"])

    def delete_attribute_type(self,attribute, entity_predicate):
        delete_schema_attribute(self,attribute["vertical"],attribute["entity_type"],attribute["attribute_name"])
        delete_schema_entity_predicate(self,entity_predicate["vertical"],entity_predicate["entity_type"],entity_predicate["attribute_type"],entity_predicate["attribute_name"])
