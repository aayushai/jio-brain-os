from .config import *
import logging as logger

def process_query(self,query):
	logger.debug(EXECUTE)
	cursor = []
	try:
		cursor = self.db.aql.execute(query)
		cursor = list(cursor)
	
	except Exception as e:
		logger.error(e)
		exception = str(e)
		status["ok"] = False
		status["msg"] = (EXCEPTION + exception)
	
	logger.info(EXECUTED)
	return cursor,status