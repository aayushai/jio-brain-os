status = {
		"ok": True,
		"msg": "No Error"
	}

EXECUTE = "execute method reached"
EXCEPTION = "DB error "
EXECUTED = "Query executed"