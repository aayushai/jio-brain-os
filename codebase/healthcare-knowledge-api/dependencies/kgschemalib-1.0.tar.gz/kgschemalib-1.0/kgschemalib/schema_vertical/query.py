add_query_predicate = "LET doc = document('schema_vertical/%s') \
            UPSERT { _key: '%s' } \
            INSERT { _key: '%s', '%s': {'entity_type': [],'predicate_type': ['%s']}} \
            UPDATE { %s: {predicate_type: append(doc.%s.predicate_type, '%s') }} IN schema_vertical"

add_query_entity = "LET doc = document('schema_vertical/%s') \
            UPSERT { _key: '%s' } \
            INSERT { _key: '%s', '%s': {'entity_type': ['%s'],'predicate_type': []}} \
            UPDATE { %s: {entity_type: append(doc.%s.entity_type, '%s') }} IN schema_vertical"

delete_query_predicate = "LET doc = DOCUMENT('schema_vertical/%s') \
        UPDATE doc WITH {%s: {predicate_type: remove_value(doc.%s.predicate_type, '%s')}} IN schema_vertical"

delete_query_entity = "LET doc = DOCUMENT('schema_vertical/%s') \
        UPDATE doc WITH {%s: {entity_type: remove_value(doc.%s.entity_type, '%s')}} IN schema_vertical"

get_query = "LET doc = DOCUMENT('schema_vertical/%s') \
        RETURN doc.%s"