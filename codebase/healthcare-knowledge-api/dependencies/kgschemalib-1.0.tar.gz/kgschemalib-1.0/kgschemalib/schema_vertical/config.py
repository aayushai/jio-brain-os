NAMESPACE_DELIMITER = "_"

# schema_vertical log messages
ADD_SCHEMA_VERTICAL_START = "add_schema_vertical method entered"
ADD_SCHEMA_VERTICAL_COMPLETED = "add_schema_vertical method completed"
GET_SCHEMA_VERTICAL_START = "get_schema_vertical method entered"
GET_SCHEMA_VERTICAL_COMPLETED = "get_schema_vertical method entered"
DELETE_SCHEMA_VERTICAL_START = "delete_schema_vertical method entered"
DELETE_SCHEMA_VERTICAL_COMPLETED = "delete_schema_vertical method entered"