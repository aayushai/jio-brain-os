import logging as logger
from .config import *
from .query import *
from kgschemalib.arango_utils.query_handler import process_query

def add_schema_vertical(self, is_predicate, vertical, entity_type):
    logger.debug(ADD_SCHEMA_VERTICAL_START)

    if is_predicate:
        query = add_query_predicate
    else:
        query = add_query_entity
    
    query_ = query%(vertical,vertical,vertical,vertical,entity_type,vertical,vertical,entity_type)
    cursor, status = process_query(self,query_)
    
    logger.info(ADD_SCHEMA_VERTICAL_COMPLETED)
    return status


def delete_schema_vertical(self, is_predicate, vertical, entity_type): #assuming exists
    logger.debug(DELETE_SCHEMA_VERTICAL_START)

    if is_predicate:
        query = delete_query_predicate
    else:
        query = delete_query_entity
    
    query_ = query%(vertical,vertical,vertical,entity_type)
    cursor, status = process_query(self, query_)

    logger.info(DELETE_SCHEMA_VERTICAL_COMPLETED)
    return status


def get_schema_vertical(self, vertical):
    logger.debug(GET_SCHEMA_VERTICAL_START)

    query = get_query
    query_ = query%(vertical,vertical)
    cursor, status = process_query(self, query_)

    logger.info(GET_SCHEMA_VERTICAL_COMPLETED)
    return cursor, status