from setuptools import find_packages, setup

setup(
    name="kgschemalib",
    description="updates given schema details to database",
    packages=find_packages(),
    install_requires=[
        "python-arango==7.2.0",
        "singleton-decorator==1.0.0",
        "retry==0.9.2"
    ],
    version="1.0"
)