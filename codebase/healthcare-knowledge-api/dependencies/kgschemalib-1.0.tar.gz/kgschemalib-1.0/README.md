# Schema Library 
Updates the given schema details to database

## Prerequisites
```
Python >= 3.9
python-arango == 7.2.0
singleton-decorator == 1.0.0
retry == 0.9.2
```

## Installation

### Download source code
```bash
git clone
cd kgschemalib/
```

### Build schema_library on local
```bash
pip3 install .
```

### Install schema_library from nexus
```bash=
pip3 install kgschemalib --trusted-host nexus.rjil.ril.com --index-url http://Brain_os:Brain_os@nexus.rjil.ril.com:9081/repository/Brain_os-py-group/simple/
``` 

## Tree Structure
```
kgschemalib
 ┣ kgschemalib
 ┃ ┣ arango_utils
 ┃ ┃ ┣ config.py
 ┃ ┃ ┣ query_handler.py
 ┃ ┃ ┗ __init__.py
 ┃ ┣ schema_attribute
 ┃ ┃ ┣ attribute.py
 ┃ ┃ ┣ config.py
 ┃ ┃ ┣ query.py
 ┃ ┃ ┗ __init__.py
 ┃ ┣ schema_entity_predicate
 ┃ ┃ ┣ config.py
 ┃ ┃ ┣ entity_predicate.py
 ┃ ┃ ┣ query.py
 ┃ ┃ ┗ __init__.py
 ┃ ┣ schema_vertical
 ┃ ┃ ┣ config.py
 ┃ ┃ ┣ query.py
 ┃ ┃ ┣ vertical.py
 ┃ ┃ ┗ __init__.py
 ┃ ┣ schema_client.py
 ┃ ┗ __init__.py
 ┣ README.md
 ┗ setup.py
```

## Create distribution
```bash=
python3 setup.py sdist
```

## Upload to nexus
```bash=
twine upload -r nexus --repository-url http://10.141.51.157:9081/repository/Brain_os-py/ -u Brain_os -p Brain_os ./dist/*
```