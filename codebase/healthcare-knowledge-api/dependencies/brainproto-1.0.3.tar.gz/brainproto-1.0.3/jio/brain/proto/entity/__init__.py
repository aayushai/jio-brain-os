from . import entity_pb2
from . import entity_pb2_grpc
