
import setuptools

setuptools.setup(
    name="brainproto",
    version="1.0.3",
    author="me",
    author_email="me@example.com",
    description="Knowlegde graph apis",
    long_description="",
    long_description_content_type="text/markdown",
    packages=setuptools.find_packages("."),

)
